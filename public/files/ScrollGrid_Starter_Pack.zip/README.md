
# ScrollGrid Image Archive

This is your starter ScrollGrid archive for uploading images.

## How to Use

1. Add your images to the `images/` folder.
2. Name them using the format: THEME_CHARACTER_SCROLL_DATE.jpg
   Example: DRAGON_MIRAI_GATE3_2025-05-01.jpg
3. Open `index.html` in a browser to view your ScrollGrid gallery.
4. Upload everything to GitHub to create a live archive.

## GitHub Pages (optional)
To publish your archive:
- Go to your repo's Settings > Pages
- Set source to the main branch and root (`/`)
- Your archive will be live at `https://yourusername.github.io/ScrollGrid`

